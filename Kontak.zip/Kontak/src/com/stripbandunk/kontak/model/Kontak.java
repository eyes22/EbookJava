package com.stripbandunk.kontak.model;

public class Kontak {

	public String nama;

	public String telepon;

	public String email;

	public Kontak() {
	}

	public Kontak(String nama, String telepon, String email) {
		this.nama = nama;
		this.telepon = telepon;
		this.email = email;
	}

	@Override
	public String toString() {
		return nama;
	}

}
